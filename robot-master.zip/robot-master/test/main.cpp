#define BOOST_TEST_MODULE test_robot_suite
#include <boost/test/unit_test.hpp>
